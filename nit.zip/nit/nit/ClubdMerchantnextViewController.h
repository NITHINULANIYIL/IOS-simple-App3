//
//  ClubdMerchantnextViewController.h
//  nit
//
//  Created by Antzcamp-Mac2 on 24/12/13.
//  Copyright (c) 2013 Antzcamp-Mac2. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClubdMerchantnextViewController : UIViewController
@property(strong)NSString *va;
@property(strong)NSString *va1;
@end
