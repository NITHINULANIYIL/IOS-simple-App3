//
//  ClubdMerchantViewController.m
//  nit
//
//  Created by Antzcamp-Mac2 on 24/12/13.
//  Copyright (c) 2013 Antzcamp-Mac2. All rights reserved.
//

#import "ClubdMerchantViewController.h"
#import "ClubdMerchantnextViewController.h"
@interface ClubdMerchantViewController ()

@end

@implementation ClubdMerchantViewController
@synthesize text1,text2;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
     text1=[[UITextField alloc]initWithFrame:CGRectMake(10, 50, 100, 40)];
    [self.view addSubview:text1];
    text2=[[UITextField alloc]initWithFrame:CGRectMake(10, 100, 100, 40)];
    [self.view addSubview:text2];
    text1.backgroundColor=[UIColor redColor];
    text2.backgroundColor=[UIColor redColor];
    text2.secureTextEntry=YES;
    text2.delegate=self;
    text1.delegate=self;
    
  UIButton* signinokButton = [UIButton buttonWithType:UIButtonTypeCustom];
    signinokButton.frame = CGRectMake( (self.view.frame.size.width / 4) - 68,390, 295, 40);
    [signinokButton setTitle:@"Sign In" forState:UIControlStateNormal];
    signinokButton.backgroundColor=[UIColor yellowColor];
        [signinokButton addTarget:self action:@selector(signinokButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:signinokButton];
    
    UIImage * image2=[UIImage imageNamed:@"images.jpg"];
    UIImageView * image1=[[UIImageView alloc]initWithFrame:CGRectMake(100, 110, 100, 100)];
    
    [image1 setImage:image2];
    [self.view addSubview:image1];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)signinokButtonClicked{
    text2.text=[NSString stringWithFormat:@"%@%@",text2.text,text1.text];
    
    ClubdMerchantnextViewController * c=[[ClubdMerchantnextViewController alloc]init];
    c.va = text2.text;
    c.va1 = @"hi";
    
    [self.navigationController pushViewController:c animated:YES];
  
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

@end
