//
//  ClubdMerchantnextViewController.m
//  nit
//
//  Created by Antzcamp-Mac2 on 24/12/13.
//  Copyright (c) 2013 Antzcamp-Mac2. All rights reserved.
//

#import "ClubdMerchantnextViewController.h"

@interface ClubdMerchantnextViewController ()

@end

@implementation ClubdMerchantnextViewController
@synthesize va,va1;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{ [super viewDidLoad];
    self.view.backgroundColor=[UIColor yellowColor];

    //[self.navigationController setToolbarHidden:YES animated:YES];
    // self.navigationController.navigationBarHidden = YES;
    //[self.navigationItem setHidesBackButton:YES animated:YES];
    NSLog(@"%@",va);
    NSLog(@"%@",va1);
   UITextField * text1=[[UITextField alloc]initWithFrame:CGRectMake(10, 300, 100, 40)];
    
    text1.text=va1;
    text1.backgroundColor=[UIColor redColor];
    [self.view addSubview:text1];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
