//
//  Nitin2.h
//  nit
//
//  Created by Antzcamp-Mac2 on 23/12/13.
//  Copyright (c) 2013 Antzcamp-Mac2. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class NITIN;

@interface Nitin2 : NSManagedObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NITIN *nitin1;

@end
