//
//  Nitin2.m
//  nit
//
//  Created by Antzcamp-Mac2 on 23/12/13.
//  Copyright (c) 2013 Antzcamp-Mac2. All rights reserved.
//

#import "Nitin2.h"
#import "NITIN.h"


@implementation Nitin2

@dynamic name;
@dynamic nitin1;

@end
