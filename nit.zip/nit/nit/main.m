//
//  main.m
//  nit
//
//  Created by Antzcamp-Mac2 on 23/12/13.
//  Copyright (c) 2013 Antzcamp-Mac2. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ClubdMerchantAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ClubdMerchantAppDelegate class]));
    }
}
