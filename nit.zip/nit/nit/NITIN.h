//
//  NITIN.h
//  nit
//
//  Created by Antzcamp-Mac2 on 23/12/13.
//  Copyright (c) 2013 Antzcamp-Mac2. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Nitin2;

@interface NITIN : NSManagedObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSSet *nithagga;
@end

@interface NITIN (CoreDataGeneratedAccessors)

- (void)addNithaggaObject:(Nitin2 *)value;
- (void)removeNithaggaObject:(Nitin2 *)value;
- (void)addNithagga:(NSSet *)values;
- (void)removeNithagga:(NSSet *)values;

@end
