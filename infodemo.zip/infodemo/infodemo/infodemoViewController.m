//
//  infodemoViewController.m
//  infodemo
//
//  Created by Antzcamp-Mac2 on 08/08/12.
//  Copyright (c) 2012 Antzcamp-Mac2. All rights reserved.
//

#import "infodemoViewController.h"
#import "infodemoAppDelegate.h"

@interface infodemoViewController ()

@end

@implementation infodemoViewController
@synthesize name,address,phone;
@synthesize status;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    self.name=nil;
    self.address=nil;
    self.phone =nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void) save
{
    NSLog(@"%@",name.text);
    infodemoAppDelegate *appDelegate =
    [[UIApplication sharedApplication] delegate];
    
    NSManagedObjectContext *context =
    [appDelegate managedObjectContext];
    NSManagedObject *newContact;
    newContact = [NSEntityDescription
                  insertNewObjectForEntityForName:@"INFO"
                  inManagedObjectContext:context];
    [newContact setValue:name.text forKey:@"name"];
    [newContact setValue:address.text forKey:@"address"];
    [newContact setValue:phone.text forKey:@"phone"];
    name.text = @"";
    address.text = @"";
    phone.text = @"";
    NSError *error;
    [context save:&error];

}
-(void)find
{

    infodemoAppDelegate *appDelegate =
    [[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *context =
    [appDelegate managedObjectContext];
    NSEntityDescription *entityDesc =
    [NSEntityDescription entityForName:@"INFO"
                inManagedObjectContext:context];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setEntity:entityDesc];
    NSPredicate *pred =
    [NSPredicate predicateWithFormat:@"(name = %@)",
     name.text];
    [request setPredicate:pred];
    NSManagedObject *matches = nil;
    NSError *error;
    NSArray *objects = [context executeFetchRequest:request
                                              error:&error];
    if ([objects count] == 0) {
        status.text = @"No matches";
    } else {
        matches = [objects objectAtIndex:0];
        address.text = [matches valueForKey:@"address"];
        phone.text = [matches valueForKey:@"phone"];
        status.text = [NSString stringWithFormat:
                       @"%d matches found", [objects count]];
    }

    
    
    







}

@end
