//
//  infodemoViewController.h
//  infodemo
//
//  Created by Antzcamp-Mac2 on 08/08/12.
//  Copyright (c) 2012 Antzcamp-Mac2. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface infodemoViewController : UIViewController
{
    UITextField * name;
    UITextField* address;
    UITextField* phone;
    UILabel * status;

}
@property (strong,nonatomic)IBOutlet UITextField * name;
@property (strong,nonatomic)IBOutlet UITextField * address;
@property (strong,nonatomic)IBOutlet UITextField * phone;
@property (strong,nonatomic)IBOutlet UILabel * status;
//@property ( strong, nonatomic) NSManagedObjectContext *managedObjectContext;
-(IBAction)save;
-(IBAction)find;
-(IBAction)done;

@end
