//
//  infodemoAppDelegate.h
//  infodemo
//
//  Created by Antzcamp-Mac2 on 08/08/12.
//  Copyright (c) 2012 Antzcamp-Mac2. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "infodemoViewController.h"

@interface infodemoAppDelegate : UIResponder <UIApplicationDelegate>
{

    infodemoViewController * viewController;
}

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;
@property (strong,nonatomic) IBOutlet infodemoViewController * viewController;

@end
