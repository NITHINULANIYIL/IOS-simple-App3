//
//  main.m
//  infodemo
//
//  Created by Antzcamp-Mac2 on 08/08/12.
//  Copyright (c) 2012 Antzcamp-Mac2. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "infodemoAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([infodemoAppDelegate class]));
    }
}
